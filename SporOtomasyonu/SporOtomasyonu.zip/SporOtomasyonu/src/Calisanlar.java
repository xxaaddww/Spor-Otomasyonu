public interface Calisanlar {


    abstract void BilgiGoster(String ad,String soyad,int maas);
    abstract void ZamYap(String ad,String soyad,int maas);
    abstract void PersonelEkle(String ad,String soyad,int maas);




}
